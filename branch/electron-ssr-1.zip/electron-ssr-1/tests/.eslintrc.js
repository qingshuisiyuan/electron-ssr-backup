module.exports = {
  globals: {
    'it': true,
    'describe': true
  }
}
