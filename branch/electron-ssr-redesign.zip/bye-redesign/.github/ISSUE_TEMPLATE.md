<!-- 请注意，发起issue一般都是为了报错错误，如果只是提问请加入TG群，如果非要在issue中提问，请在issue上加上question的Label。另外在发起issue请请先阅读FAQ -->
<!-- 请再次注意，不要在issue的任何地方出现你的服务器配置，包括截图！ -->
## Your os
<!-- Mac?Windows?Linux(Ubuntu?CentOs?...etc)? -->

## The version of electron-ssr
<!-- 在主窗口的title上有 -->

## What's the problem
<!-- 请描述清楚你要提交的issue内容 -->

## App log here
<!-- 粘贴上你的应用日志，点击菜单-帮助-查看日志获取，并删除其中服务器配置数据 -->
